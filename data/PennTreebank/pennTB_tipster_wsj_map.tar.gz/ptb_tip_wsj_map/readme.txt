
README File for the Penn Treebank / TIPSTER WSJ Mapping Tables
--------------------------------------------------------------

The Penn TreeBank Project (PTB) selected a 1-million word sample from
the TIPSTER Wall Street Journal text archive for part-of-speech
tagging and syntactic parsing; in preparing the data for annotation,
the SGML markup information from the source data files was removed,
but no listing was kept of the original DOC numbers that uniquely
identified each story in the full archive.

This WSJ archive was first released in 1991 on the ACL/DCI cdrom, and
spanned most of a 3-year period, 1987-1989.  It was re-released, with
repairs, on volume 1 of the 3-cdrom TIPSTER text collection; the
repairs included normalizing the file names, enhancing the DOCNO
strings that were assigned to uniquely identify each story in the
corpus, and eliminating unintentional duplications of many stories.
Owing to these repairs, the TIPSTER release is the definitive one for
this archive.  The 3-year WSJ collection includes a total of 98,732
stories; PTB selected 2499 of these for syntactic annotation, and
this set has been distributed on both the "version 2" and "version 3"
releases of PTB.

The "version 2" release included the raw text for each WSJ story,
which was the result of stripping out all SGML tagging from the source
archive version, making a few minor changes to the text where
necessary (to fix errors in punctuation or spelling), and placing each
news story (each selected DOC element) into a separate file.  Each
story/file is identified simply by a sequence number ("wsj_0001"
through "wsj_2499"), and all annotated versions of a given story share
that as the common portion of their file names.  (The tagged, parsed,
merged and raw versions are distinguished by directory path and by an
appropriate 3-letter extension to the file name.)

The three "map" files in this directory provide the relation between
the 2499 PTB file names and the corresponding DOCNO strings in
TIPSTER.  In the process of correlating the two corpora, two
unexpected properties were discovered regarding the PTB WSJ
collection:

(1) A handful of stories selected by PTB turned out to have mutually
    identical content -- that is, even though these stories may have
    been drawn from distinct points in the TIPSTER archive, their text
    content, as prepared for annotation by PTB, yielded the exact same
    stream of words.  (Presumably, the POS and parsing annotation of
    these stories should have yielded the same results as well, though
    this doesn't concern us here.)

(2) A couple dozen PTB files were found to contain two consecutive WSJ
    stories from the TIPSTER archive -- in these cases, the process
    that extracted the PTB sample from TIPSTER had somehow missed a
    story boundary in the source data.

Because of these issues, three mapping tables are given:

 * ptb_tip.tbl :

   This is the main mapping table, covering the 2465 PTB WSJ files
   whose content is unique and which equate to exactly one story (DOC
   unit) in TIPSTER.  Each line contains three fields, as follows:

   PTB_File  TIPSTER_DOCNO  TIPSTER_File


 * ptb_dual_tip.tbl :

   This table covers the 22 PTB files in which two distinct TIPSTER
   stories have been concatenated together.  Each line is formatted as
   follows:

   PTB_File  1st_TIPSTER_DOCNO + 2nd_TIPSTER_DOCNO  TIPSTER_File


 * ptb_duplicates.tbl :

   This table covers the 12 PTB files whose text content is fully
   identical to one of the PTB files listed in the main map table
   (ptb_tip.tbl).  The format of each line is as follows:

   PTB_File  ==  PTB_File


It so happens that all 12 duplicate files are identical to a single
file in the main table: 01/wsj_0190 -- and they are all therefore
identical to each other.  The one TIPSTER source file that maps to
01/wsj_0190 -- DOCNO WSJ891102-0175 from file 1989/wsj9_001 on the
TIPSTER Vol. 1 cdrom -- serves equally well as the source for these 12
duplications.


David Graff <graff@ldc.upenn.edu>
Linguist Data Consortium
January 30, 2002

